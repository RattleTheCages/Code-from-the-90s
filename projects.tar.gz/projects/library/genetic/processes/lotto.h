#ifndef UUUUU
#define UUUUU

class lotto_o {
  public:
    int picks[6];
    int predictions[6];
};
#endif
